import streamlit as st

def main():
    st.title("Curriculum AI Admin Panel")
    st.write("View curriculum, regenerate questions, upload new textbook repos.")

if __name__ == '__main__':
    main()
